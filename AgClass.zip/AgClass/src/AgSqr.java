
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;

public class AgSqr extends Agent{
	 @Override
	    protected void setup() {
	        System.out.println("Agent Sqr " + getLocalName() + " démarré.");

	        addBehaviour(new TickerBehaviour(this, 1000) { // Tick toutes les 1 seconde
	            private int n = 0;

	            @Override
	            protected void onTick() {
	                ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
	                msg.addReceiver(getAID("AgClass")); // Envoie au serveur
	                msg.setContent(String.valueOf(n * n));
	                send(msg);
	                n++;
	            }
	        });
	    }

}

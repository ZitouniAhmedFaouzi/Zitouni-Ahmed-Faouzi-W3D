
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;

import java.util.ArrayList;
import java.util.Collections;

public class AgClass extends Agent {
	 private ArrayList<Integer> sortedList = new ArrayList<>();

	    protected void setup() {
	        System.out.println("Agent serveur " + getLocalName() + " démarré.");
	        
	        addBehaviour(new CyclicBehaviour() {
	            @Override
	            public void action() {
	                // Attendre et recevoir des messages
	                jade.lang.acl.ACLMessage msg = receive();
	                if (msg != null) {
	                    try {
	                        int number = Integer.parseInt(msg.getContent());
	                        synchronized (sortedList) {
	                            sortedList.add(number);
	                            Collections.sort(sortedList);
	                            System.out.println("Liste triée : " + sortedList);
	                        }
	                    } catch (NumberFormatException e) {
	                        System.err.println("Erreur lors de la réception : " + e.getMessage());
	                    }
	                } else {
	                    block(); // Met l'agent en attente jusqu'à réception d'un message
	                }
	            }
	        });
	    }

}

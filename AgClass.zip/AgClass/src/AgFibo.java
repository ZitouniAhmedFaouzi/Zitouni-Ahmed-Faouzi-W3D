
import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;

public class AgFibo extends Agent {
	@Override
    protected void setup() {
        System.out.println("Agent Fibonacci " + getLocalName() + " démarré.");

        addBehaviour(new TickerBehaviour(this, 1000) { // Tick toutes les 1 seconde
            private int a = 0, b = 1;

            @Override
            protected void onTick() {
                ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
                msg.addReceiver(getAID("AgClass")); 
                msg.setContent(String.valueOf(a));
                send(msg);

                // Génération de Fibonacci
                int temp = a + b;
                a = b;
                b = temp;
            }
        });
    }

}

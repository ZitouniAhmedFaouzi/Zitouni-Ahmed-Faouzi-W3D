
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;
public class MainContainer {
	   public static void main(String[] args) {
	        jade.core.Runtime runtime = jade.core.Runtime.instance();
	        Profile profile = new ProfileImpl();
	        profile.setParameter(Profile.MAIN_HOST, "localhost");
	        profile.setParameter(Profile.MAIN_PORT, "1100");

	        AgentContainer mainContainer = runtime.createMainContainer(profile);
	        try {
	            // Lancer les agents
	            AgentController serverAgent = mainContainer.createNewAgent("AgClass", AgClass.class.getName(), null);
	            AgentController fiboAgent = mainContainer.createNewAgent("AgFibo", AgFibo.class.getName(), null);
	            AgentController sqrAgent = mainContainer.createNewAgent("AgSqr", AgSqr.class.getName(), null);

	            serverAgent.start();
	            fiboAgent.start();
	            sqrAgent.start();
	        } catch (StaleProxyException e) {
	            e.printStackTrace();
	        }
	    }
}
